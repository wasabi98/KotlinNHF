package main


import javafx.animation.KeyFrame
import javafx.animation.Timeline
import javafx.application.Application
import javafx.event.ActionEvent
import javafx.event.EventHandler
import javafx.geometry.Pos
import javafx.scene.Scene
import javafx.scene.control.Button
import javafx.scene.control.TextField
import javafx.scene.image.Image
import javafx.scene.image.ImageView
import javafx.scene.input.MouseEvent
import javafx.scene.layout.*
import javafx.scene.paint.Color
import javafx.scene.shape.Rectangle
import javafx.scene.text.Text
import javafx.stage.Stage
import javafx.util.Duration


class Cell(var isAlive: Boolean = false, var neighbors: Int = 0) : Rectangle()
{

    var locked: Boolean = false
    init {
        setWidth(40.0)
        setHeight(40.0)
        setFill(Color.WHITE)
        setStroke(Color.LIGHTGRAY)
        setOnMouseClicked(EventHandler<MouseEvent> {
            if(!locked)
            {
                if(isAlive)
                {
                    isAlive = false
                    fill=Color.WHITE
                }
                else
                {
                    isAlive = true
                    fill=Color.BLACK
                }
            }

        })
    }

    public fun update() // Table calls this function on each individual cell to update the amount of alive neighbors. The cell changes its isAlive state according to the game rules
    {

        when(neighbors)
        {
            2 -> {}
            3 ->
            {
                isAlive = true
                fill = Color.BLACK
            }
            else ->
            {
                isAlive = false
                fill = Color.WHITE
            }
        }
    }
    fun clear()
    {
        isAlive = false
        neighbors = 0
        locked = false
        fill = Color.WHITE
    }


}

class Table(var width: Int = 0, var height: Int = 0) : GridPane()
{
    var board =  arrayOf<Array<Cell>>()


    init
    {
        board = arrayOf<Array<Cell>>()
        for(i  in 0 until height)
        {
            var tmp: Array<Cell> = arrayOf<Cell>()
            for(j in 0 until width)
            {
                var cell = Cell()
                tmp += cell // += is the operator for push!? You learn something new everyday

            }
            board += tmp
        }
        for(i  in 0 until height)
        {
            for(j  in 0 until width)
            {
                this.add(board[i][j], j , i ,1,1)
            }
        }

    }
    fun refresh()
    {
        for(i in 0 until height)
        {
            for(j in 0 until width)
            {
                var neighbors: Int = 0
                for(k in i-1 until i+2)
                {
                    for(l in j-1 until j+2)
                    {
                        if(!(k < 0 || l < 0 || k >= height || l >= width || (k == i && l == j)))
                            if(board[k][l].isAlive)
                            {
        /*The Spear 2*/          board[i][j].neighbors++
                            }
                    }
                }
            }
        }
        for(i in 0 until height)
        {
            for (j in 0 until width)
            {
                board[i][j].update()
                board[i][j].neighbors = 0
            }
        }

    }
    fun reset()
    {
        for(i  in 0 until height)
        {
            for(j  in 0 until width)
            {
                board[i][j].clear()
            }
        }
    }
    fun locked(locked: Boolean)
    {
        for(i  in 0 until height)
        {
            for (j in 0 until width)
            {
                board[i][j].locked = locked
            }
        }
    }

}



class Game(var width: Int, var height: Int) : Stage()
{
    lateinit var gameScene: Scene
    lateinit var table: Table
    lateinit var pausePlay: Button
    lateinit var reset: Button
    var running = false

    init {
        title = "Game of Life"
        table = Table(width, height)
        val root = FlowPane()

        root.children.add(table)

        val hBox = HBox()
        hBox.alignment = Pos.BOTTOM_LEFT

        reset = Button()
        val rstImg = ImageView()
        rstImg.image = Image("reset.png")
        reset.graphic = rstImg
        hBox.children.add(reset)

        pausePlay = Button()
        val psImg = ImageView()
        psImg.image = Image("pause.png")
        pausePlay.graphic = psImg
        hBox.children.add(pausePlay)

        root.children.add(hBox)
        gameScene = Scene(root, width*41.0, height*41.0+72)
        setScene(gameScene)
        show()
    }

}

class NewGameHandler(val width: TextField, val height: TextField, var msg: Text)  : EventHandler<ActionEvent>
{
    var w: Int = 0
    var h: Int = 0
    lateinit var game: Game
    override fun handle(e: ActionEvent) {

        var wCheck: Boolean = false
        var hCheck: Boolean = false
        try
        {
            w = Integer.parseInt(width.getText())
            wCheck = true
        }
        catch (e: NumberFormatException)
        {
            msg.text = "That's not a valid number"
        }

        try
        {
            h = Integer.parseInt(height.getText())
            hCheck = true
        }
        catch (e: NumberFormatException)
        {
            msg.text = "That's not a valid number"
        }
        if(wCheck && hCheck)
        {
            game = Game(w,h)
            /*game.table.board[3][4].isAlive = true
            game.table.board[3][4].fill = Color.BLACK
            game.table.board[4][4].isAlive = true
            game.table.board[4][4].fill = Color.BLACK
            game.table.board[5][4].isAlive = true
            game.table.board[5][4].fill = Color.BLACK*/

            val timeline = Timeline(KeyFrame(Duration.millis(500.0),EventHandler {
                game.table.refresh()
            }))
            timeline.cycleCount = Timeline.INDEFINITE
            game.pausePlay.onAction = EventHandler<ActionEvent> {
                if(game.running)
                {
                    timeline.pause()
                    game.running = false
                    game.table.locked(false)
                }
                else
                {
                    timeline.play()
                    game.running = true
                    game.table.locked(true)
                }
            }
            game.reset.onAction = EventHandler<ActionEvent> {
                if(!game.running)
                    game.table.reset()
            }
        }
    }

}

class Menu() : Application() {
    lateinit var newGame : Button
    lateinit var widthTxt : Text
    lateinit var widthGet : TextField
    lateinit var heightTxt : Text
    lateinit var heightGet : TextField
    lateinit var msg : Text
    lateinit var exit : Button

    override fun start(primaryStage: Stage) {
        newGame = Button("New Game")
        widthTxt = Text("Width: ")
        widthGet = TextField("20")
        heightTxt = Text("Height: ")
        heightGet = TextField("20")
        msg = Text()
        exit = Button("Exit")

        exit.onAction = EventHandler<ActionEvent> { primaryStage.close() }
        newGame.onAction = NewGameHandler(widthGet, heightGet, msg)


        var vBox = VBox()
        vBox.setAlignment(Pos.TOP_CENTER)
        vBox.getChildren().add(newGame)
        vBox.getChildren().add(FlowPane(widthTxt, widthGet, heightTxt, heightGet))
        vBox.getChildren().add(msg)
        vBox.getChildren().add(exit)

        val root = StackPane()
        root.getChildren().add(vBox)
        val scene = Scene(root, 200.0, 120.0)


        primaryStage.title = "Menu"
        primaryStage.scene = scene
        primaryStage.show()


    }
}

fun main(args: Array<String>)
{
    Application.launch(Menu::class.java, *args)
    /*var table = Table(
        10,
        10
    )

    table.board[3][4].isAlive = true
    table.board[4][4].isAlive = true
    table.board[5][4].isAlive = true*/

    /*while(true)
    {
        Thread.sleep(500)
        for(i in 0 until table.width)
        {
            for(j in 0 until table.height)
            {
                print("${table.board[i][j].isAlive} ")

            }
            println()

        }
        table.refresh()
    }*/


}